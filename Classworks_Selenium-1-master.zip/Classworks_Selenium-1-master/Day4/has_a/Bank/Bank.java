
public class Bank {
	private BankAccount[] accounts=new BankAccount[5];
	
	public Bank(BankAccount[] accounts) {
		super();
		this.accounts = accounts;
	}

	public Bank() {
		super();
	}

	public BankAccount[] getAccounts() {
		return accounts;
	}

	public void setAccounts(BankAccount[] accounts) {
		this.accounts = accounts;
	}
	
	//Method to verify the account existence	
	public BankAccount checkAccount(String accountNo){
		BankAccount check=null;
		for(int i=0;i<accounts.length;i++){
			if(accounts[i].getAccountNo().equals(accountNo)){
				check = accounts[i]; 
			}
		}
		return check;
	}
	
	public double getBalance(String accountno){
		double balance=-0.0;
		BankAccount account=checkAccount(accountno);
		if(account!=null){
			balance= account.getAccountBalance();
		}
		//else{
			//System.out.println("Error code: #111 Account Number Not Exist !!! ");
			//balance = 0.0;
		//}
		return balance;
	}
	
	public int deposit(String accountNo, double amount){
		
		//double deposit=getBalance(accountNo)+amount;
		BankAccount account = checkAccount(accountNo);
		if(account !=null) {
			account.setAccountBalance(account.getAccountBalance() + amount);
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public int withdraw(String accountNo, double amount){
		
		BankAccount account = checkAccount(accountNo);
		if(account !=null) {
			if(account.getAccountBalance() > amount) {
				account.setAccountBalance(account.getAccountBalance() - amount);
				return 1;
			}
			else{
				return 2;
			}
		}
		else{
			return 0;
		}
	}
	
	public int transferMoney(String fromAccount,String toAccount,double amount){
/*		double transfer=0.0;
		if(getBalance(fromAccount)>amount){
			checkAccount(fromAccount).setAccountBalance(getBalance(fromAccount)-amount);
			System.out.println("FromAccount " +fromAccount+" Balance after transfer: "+checkAccount(fromAccount).getAccountBalance());
			checkAccount(toAccount).setAccountBalance(getBalance(toAccount)+amount);
			System.out.println("ToAccount " +toAccount+" Balance after transfer: "+checkAccount(toAccount).getAccountBalance());
		}
		else{
			System.out.println("Error code: #222 Insufficient Balance !!! ");
		}
*/

			int wstatus = withdraw(fromAccount, amount);
			if(wstatus ==1)		{
				int dstatus = deposit(toAccount, amount);
				if(dstatus==1){
					return 1;
				}
				else{
					return dstatus; 
				}
			}
			else{
				return wstatus;
			}

	}
}
