
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b=new Bank();
		BankAccount[] accounts=new BankAccount[5];
		accounts[0]=new BankAccount("12345","Gopi",1000);
		accounts[1]=new BankAccount("12346","Raja",10);
		accounts[2]=new BankAccount("12347","Balan",200);
		accounts[3]=new BankAccount("12348","Giri",2000);
		accounts[4]=new BankAccount("12349","Gopal",10000);
		b.setAccounts(accounts);
		
		
		System.out.println("Account Name is "+ b.checkAccount("12111348"));
		System.out.println("Account Balance is "+b.getBalance("1233344"));
		/*
		System.out.println("Account Balance after Deposit: "+b.deposit("12346", 1000));
		System.out.println("Account Balance after Withdraw: "+b.withdraw("12346", 10));
		
		System.out.println("Amount Transfer(negative): ");
		b.transferMoney("12349", "12346", 11000);
		
		System.out.println("Amount Transfer(positive): ");
		b.transferMoney("12349", "12346", 5000);*/
	}

}
   