package com.htc.oops.has_a;

public class Main {

	public static void main(String[] args) {
		
			
		Employee departmentHead=new Employee(20723,"Raju","Department Head");
		
		
		// Array of Object
		Employee[] employees=new Employee[5];
		
		employees[0]=new Employee(1,"Gopi","Technical Trainer");
		employees[1]=new Employee(2,"Ashok","Technical Trainer");
		employees[2]=new Employee(3,"Anish","Technical Trainer");
		
		Department department=new Department(10,"Training",departmentHead,employees);
		
		System.out.println(department.toString());
		
	}
}
