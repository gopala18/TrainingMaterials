package com.htc.oops.has_a;

import java.util.Arrays;

public class Department {

	private int deptNo;
	private String  deptName;
	private Employee deptHead;
	private Employee[] employees;
	
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Employee getDeptHead() {
		return deptHead;
	}
	public void setDeptHead(Employee deptHead) {
		this.deptHead = deptHead;
	}
	public Employee[] getEmployees() {
		return employees;
	}
	public void setEmployees(Employee[] employees) {
		this.employees = employees;
	}
	public Department(int deptNo, String deptName, Employee deptHead,
			Employee[] employees) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.deptHead = deptHead;
		this.employees = employees;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", deptName=" + deptName
				+ ", deptHead=" + deptHead + ", employees="
				+ Arrays.toString(employees) + "]";
	}
	
	
	
}
