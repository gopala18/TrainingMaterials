package has_a.bank;
// BankAccount application 
public class BankAccount {
	//Member declarations
	private String accountNo;
	private String accountName;
	private double accountBalance;
	
	//Default Constructor
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankAccount(String accountNo, String accountName) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.accountBalance=1000.00;
	}

	//parametrised  Constructor
	public BankAccount(String accountNo, String accountName,
			double accountBalance) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.accountBalance = accountBalance;
	}
	// Getters and Setters
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountName="
				+ accountName + ", accountBalance=" + accountBalance + "]";
	}
	
	
}
