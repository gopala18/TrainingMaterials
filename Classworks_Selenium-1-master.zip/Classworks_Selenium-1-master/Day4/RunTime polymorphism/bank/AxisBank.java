package has_a.bank;

public class AxisBank extends Bank{

	@Override
	public BankAccount checkAccount(String accountNo) {
		BankAccount bank=null;
		
		//foreach loop
		//for(dataype var:array/collection)
		
		for(BankAccount account:this.getAccounts()) {
			if(account.getAccountNo().equals(accountNo)) {
				bank=account;
			}
		}
		
		System.out.println("Axis bank specific implementation");
		return bank;
		
	}

	
	
}
