package interfaces.day4;

public class Main {
	public static void main(String[] args) {
		Softwares msWord=new MsWord();
		msWord.install();
		msWord.run();
		msWord.newDocument();
	}
}
