package interfaces.day4;

public interface Softwares {
	public void install();
	public void run();
	public void newDocument();
}
