package interfaces.day4;

public class MsWord implements Softwares,SystemRequirements{

	public MsWord() {
		super();
		System.out.println("Created...");
	}

	@Override
	public void install() {
		System.out.println("Installed successfully...");
	}

	@Override
	public void run() {
		System.out.println("Running...");
	}

	@Override
	public void newDocument() {
		System.out.println("New Document Created...");
	}

	@Override
	public void systemProperties() {
		// TODO Auto-generated method stub
		
	}

	
}
