package interfaces.day4;

public interface SystemRequirements {
	public void systemProperties();
}
