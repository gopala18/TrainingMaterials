package is_a.person;

public class Employee extends Person{

	private int empID;
	private String designation;
	
	public Employee(String name, int age, String address, int empID, String designation) {
		super(name, age, address);
		this.empID = empID;
		this.designation = designation;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return super.toString()+"Employee [empID=" + empID + ", designation=" + designation + "]";
	}
	
	
}
