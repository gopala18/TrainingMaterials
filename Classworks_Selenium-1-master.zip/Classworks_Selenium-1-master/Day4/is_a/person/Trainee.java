package is_a.person;

public class Trainee extends Person{

	private int traineeID;
	private String trainingBatch;
	
	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Trainee(String name, int age, String address) {
		super(name, age, address);
		// TODO Auto-generated constructor stub
	}
	public Trainee(String name, int age, String address, int traineeID, String trainingBatch) {
		super(name, age, address);
		this.traineeID = traineeID;
		this.trainingBatch = trainingBatch;
	}
	public int getTraineeID() {
		return traineeID;
	}
	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}
	public String getTrainingBatch() {
		return trainingBatch;
	}
	public void setTrainingBatch(String trainingBatch) {
		this.trainingBatch = trainingBatch;
	}
	@Override
	public String toString() {
		return super.toString()+"Trainee [traineeID=" + traineeID + ", trainingBatch=" + trainingBatch + "]";
	}
	
	
}
