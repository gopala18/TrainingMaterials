package is_a.person;

public class Main {

	public static void main(String[] args) {
		Employee employee=new Employee("Gopi",20,"Chennai",123,"Trainer");
		
		Trainee trainee=new Trainee("Charles",20,"Chennai",111,"Java");
		
		System.out.println(employee.toString());
		System.out.println(trainee.toString());
		
	}
}
