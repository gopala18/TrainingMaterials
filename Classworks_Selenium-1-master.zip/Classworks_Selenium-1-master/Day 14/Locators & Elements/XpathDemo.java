package com.htc.selenium.seleniumhq;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.htc.selenium.drivers.WebDriversFactory;

public class XpathDemo {

	public static void main(String[] args) throws InterruptedException{
		
		WebDriver driver = WebDriversFactory.getWebdriver("chrome");
        Thread.sleep(3000);

        driver.get("http://www.seleniumhq.org//");
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//*[@id=\"menu_projects\"]/a")).click();
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
        driver.manage().window().maximize();
        
        
        driver.findElement(By.xpath("//*[@id=\"menu_download\"]/a")).click();
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//*[@id=\"menu_documentation\"]/a")).click();
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//*[@id=\"menu_support\"]/a")).click();
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
        
        driver.findElement(By.xpath("//*[@id=\"menu_about\"]/a")).click();
        System.out.println(driver.getTitle());
        Thread.sleep(3000);
		driver.close();
	}

}