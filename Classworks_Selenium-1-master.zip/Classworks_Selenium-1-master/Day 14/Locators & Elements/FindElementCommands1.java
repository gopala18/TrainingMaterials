package com.htc.selenium.automationFramework;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;

import com.htc.selenium.drivers.WebDriversFactory;
public class FindElementCommands1 {
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver =  WebDriversFactory.getWebdriver("chrome");
 
		// Launch the ToolsQA WebSite
		driver.get("http://toolsqa.wpengine.com/Automation-practice-form/");
 
		// Type Name in the FirstName text box      
		driver.findElement(By.name("firstname")).sendKeys("Gopi"); 
 
		//Type LastName in the LastName text box
		driver.findElement(By.name("lastname")).sendKeys("Muruganantham");
 
		// Click on the Submit button
		Thread.sleep(5000);
		driver.findElement(By.id("submit")).click();
	}
}
