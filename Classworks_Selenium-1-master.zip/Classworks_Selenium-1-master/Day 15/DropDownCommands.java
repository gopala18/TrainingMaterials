package com.htc.selenium.automationFramework;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;

import com.htc.selenium.drivers.WebDriversFactory;

public class DropDownCommands {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver =  WebDriversFactory.getWebdriver("chrome");

		// Launch the Online Store WebSite
		driver.get("http://toolsqa.wpengine.com/automation-practice-form/");
		
		Select oSelect = new Select(driver.findElement(By.id("continents")));
		
		// select by index
		/*oSelect.selectByIndex(2);
		Thread.sleep(1000);*/

		Thread.sleep(2000);
		//select by text 
		oSelect.selectByVisibleText("Africa");
		Thread.sleep(1000);
		
		List<WebElement> elementCount = oSelect.getOptions();
		int iSize = elementCount.size();
		
		for(int i = 0 ; i<iSize ; i++) {
			String sValue = elementCount.get(i).getText();
			System.out.println(sValue);
		}
		
		//Closing browser
		//driver.close();
	}

}
