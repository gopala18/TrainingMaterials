package com.htc.selenium.automationFramework;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;

import com.htc.selenium.drivers.WebDriversFactory;

public class MultiSelectCommands {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = WebDriversFactory.getWebdriver("chrome");

		// Launch the Online Store WebSite
		driver.get("http://toolsqa.wpengine.com/automation-practice-form/");
		
		Select oSelect = new Select(driver.findElement(By.id("selenium_commands")));
		
		oSelect.selectByIndex(0);
		Thread.sleep(1000);
		oSelect.deselectByIndex(0);
		Thread.sleep(1000);
		
		oSelect.selectByVisibleText("Navigation Commands");
		Thread.sleep(1000);
		oSelect.deselectByVisibleText("Navigation Commands");
		Thread.sleep(1000);
		
		List<WebElement> elementCount = oSelect.getOptions();
		int iListSize = elementCount.size();
		for(int i = 0 ; i<iListSize ; i++) {
			String sValue = elementCount.get(i).getText();
			System.out.println(sValue);
			oSelect.selectByIndex(i);
			Thread.sleep(1000);
		}
		oSelect.deselectAll();
		driver.close();
		
	}

}
