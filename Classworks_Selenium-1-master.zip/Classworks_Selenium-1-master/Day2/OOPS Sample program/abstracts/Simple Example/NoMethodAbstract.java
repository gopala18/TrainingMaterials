package abstractEx;

public abstract class NoMethodAbstract {

	void some()
	{
		
	}
}
