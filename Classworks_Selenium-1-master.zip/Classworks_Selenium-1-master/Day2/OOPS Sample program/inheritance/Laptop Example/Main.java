package com.htc.corejava.inheritance.day2;

public class Main {
	public static void main(String[] args) {
		Lenovo lenovo=new Lenovo(45000.00,"Lv001","3rd Gen I5");
		lenovo.getLenovoDetails();
		
	}
}
