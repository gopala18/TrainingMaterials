package com.htc.corejava.io.sample;

import static java.io.File.separator;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileDemo {

	public static void main(String[] args) {
	Logger log=Logger.getLogger("com.htc.corejava.day7.io.FileDemo");	
		/*Unix--->\
		window-->/*/
		String fileName="D:"+separator+"AP Training"+separator+"TestingFiles.txt";
		String directoryName="D:"+separator+"AP Training"+separator+"FileDemo";
		File file=new File(fileName);
		
		
		
		File directory=new File(directoryName);
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("File Created...");
		
		
		/*System.out.println(file.isDirectory());
		System.out.println(file.isHidden());
		System.out.println(file.exists());
		System.out.println(file.getName());
		System.out.println(file.getPath());
		log.warning("Renaming a File...");
		log.log(Level.FINE,"Testing log");
		log.fine("Testing log");
		String newfileName="D:"+File.separator+"AP Training"+File.separator+"Testing.txt";
		File newFile=new File(fileName);
		System.out.println(file.renameTo(newFile));
		System.out.println(file.exists());
		log.severe("file closed...");
		*/
		directory.mkdir();
		System.out.println("Directory created");
	}
}
