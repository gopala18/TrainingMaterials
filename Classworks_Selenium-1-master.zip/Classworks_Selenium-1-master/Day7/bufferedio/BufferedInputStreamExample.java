package com.htc.corejava.io.bufferedio;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class BufferedInputStreamExample {
	public static void main(String args[]) {
		FileInputStream fin=null;
		BufferedInputStream bin=null;
		try {
			fin = new FileInputStream("D:\\AP Training\\Day7\\Notes.txt");
			bin = new BufferedInputStream(fin);
			int i;
			
			while ((i = bin.read()) != -1) {
				System.out.print((char) i);
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		finally {
			try {
				bin.close();
				fin.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
