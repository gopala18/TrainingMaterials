package com.htc.corejava.io.serialization.serialize;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ExternalizableDemo {

	public static void main(String[] args) {
		
		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("cust.dat"));
			oos.writeObject(new Customer("c001","ABC Ltd", new Address("3b-10/24", "XYZ Street", "Chennai", "600404")));
			oos.close();
			System.out.println("done.");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// deserialization
		
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("cust.dat"));
			Customer cust = (Customer) ois.readObject();
			System.out.println(cust);
			ois.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
