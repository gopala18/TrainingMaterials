package com.htc.corejava.io.serialization.serialize;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.htc.corejava.day1.Employee;

public class SerializeDemo {

	public static void main(String[] args) {
		
		Logger logger = Logger.getLogger("com.htc.corejava.day8.SerializeDemo");
		
		Employee emp = new Employee(101, "Rahul", 5000.0);
		
		try {
			logger.log(Level.INFO, "Serialization started");
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("empl.dat"));
			oos.writeObject(emp);
			oos.close();
			logger.info("serialized");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			logger.severe(e.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.warning(e.toString());
		}
		
	}
}
