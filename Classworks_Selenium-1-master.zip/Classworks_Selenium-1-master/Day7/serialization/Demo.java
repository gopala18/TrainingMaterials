package com.htc.corejava.io.serialization;

import java.io.Serializable;

class Demo implements Serializable
{

	private static final long serialVersionUID = -6843215951637138235L;
public int a;
 public String b;

 // Default constructor
 public Demo(int a, String b)
 {
     this.a = a;
     this.b = b;
 }

}