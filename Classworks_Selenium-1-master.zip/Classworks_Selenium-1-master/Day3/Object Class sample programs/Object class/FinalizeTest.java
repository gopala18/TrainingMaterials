package object;

public class FinalizeTest {

	int i=10;
	public FinalizeTest() {
		
	}
	public FinalizeTest(int i) {
		super();
		this.i = i;
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("Finalizing object life");
		
		// DB, file closing
		super.finalize();
	}
	
	
}
