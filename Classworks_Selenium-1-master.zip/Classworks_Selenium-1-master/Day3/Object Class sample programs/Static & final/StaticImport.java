package object;
import static java.lang.Math.*;
import static java.lang.System.*;
public class StaticImport {

	public static void main(String[] args) {
		out.println(java.lang.Math.min(10, 40));
		out.println(Math.max(10, 40));
		
	}
}
