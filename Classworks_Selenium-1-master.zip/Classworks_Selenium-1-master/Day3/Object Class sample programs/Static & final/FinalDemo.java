package object;

public class FinalDemo {

	
	public static void main(String[] args) {
		// defining a constant variable in java
		final int empID=123;
		int age=20;
		//error when re assigning a value to final variable
		//empID=12;
		
	}
	
	
}
