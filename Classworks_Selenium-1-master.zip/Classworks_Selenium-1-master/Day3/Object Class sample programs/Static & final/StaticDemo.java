package object;

public class StaticDemo {
	
	//instance variable
	//int count;
	
	// class variable;
	static int count;
	
	static{  // static block
		count=0;
	}
	
	
	StaticDemo(){
		//count=count+1;
		++count;  // increment operator
	}
	
	public int getCount() {
		return count;
	}
	// static method
	public static String getCountAsString() {
		return "The value of Count: "+count;
	}
	
	public static void main(String[] args) {
		
		StaticDemo sd=new StaticDemo();
		System.out.println(sd.getCount());
		System.out.println(StaticDemo.getCountAsString());
		
		
		StaticDemo sd1=new StaticDemo();
		System.out.println(sd1.count);
		
	}

}
