public class BoxingVariables {

     public static void main(String []args){
            int x=5;
            Integer ob = new Integer(x);        //converting int to Integer
        System.out.println(ob);
       
            Integer a=new Integer(15);   
    int i=a.intValue();                 //converting Integer to int 
    System.out.println(+i);

     }
}