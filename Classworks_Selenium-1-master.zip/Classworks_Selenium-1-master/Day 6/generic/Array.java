package com.htc.corejava.day5.generic;

public class Array<T> {
	private T t;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}

	public Array(T t) {
		super();
		this.t = t;
	}

	public Array() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
