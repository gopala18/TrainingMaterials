package com.htc.corejava.day6.collections;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		LinkedHashSet<String> hs=new LinkedHashSet<>();
		hs.add("B");
		hs.add("A");
		hs.add("F");
		hs.add("S");
		hs.add("C");
		System.out.println(hs.add("C"));
		for(String s: hs){
			System.out.println(s);
		}
	}
}
