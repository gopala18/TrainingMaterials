package com.htc.corejava.day5.collections;

import java.util.LinkedList;
import java.util.ListIterator;

public class Main {

	public static void main(String[] args) {
		/*List<Integer> numList=new ArrayList<Integer>();
		numList.add(new Integer(12));
		numList.add(new Integer(10));
		numList.add(new Integer(100));
		numList.add(new Integer(232));
		
		for(Integer in:numList){
			System.out.println(in);
		}
		Iterator<Integer> i =numList.iterator();
		while(i.hasNext()){
			System.out.println(i.next());
			
		}
		
*/		/*ArrayList<Student> students=new ArrayList<>();
		students.add(new Student(33,"Raja"));
		students.add(new Student(34,"Bala"));
		students.add(new Student(35,"Murali"));
		
	
		
		Department dept=new Department();
		dept.setDeptNo(123);
		dept.setDeptName("IT");
		dept.setStudents(students);
		
		System.out.println(dept.getStudent(34));
		System.out.println(dept.updateStudent(34, "Bala .M"));
		System.out.println(dept.getStudent(34));
		System.out.println(dept.searchStudent(37));
*/	
	
		LinkedList<Student> students=new LinkedList<>();
		students.add(new Student(3,"Raja"));
		students.add(new Student(4,"Bala"));
		students.add(new Student(5,"Murali"));
		
		Department dept=new Department();
		dept.setDeptNo(12);
		dept.setDeptName("MCA");
		dept.setStudents(students);
		
		System.out.println(dept.removeStudent(5));
		LinkedList<Student> std = dept.getStudents();
		ListIterator<Student> li=std.listIterator();
		while(li.hasNext()){
			/*if(li.next().getRegNo()==4){
				System.out.println(li.previous());
			}*/
			System.out.println(li.next());
		
		}
		
	
	
	}
}
