package com.htc.corejava.day5.collections;

import java.util.Iterator;
import java.util.LinkedList;

public class Department {

	private int deptNo;
	private String deptName;
	//private Student[] students;
	//private ArrayList<Student> students;
	private LinkedList<Student> students;
	
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	/*public ArrayList<Student> getStudents() {
		return students;
	}
	public void setStudents(ArrayList<Student> students) {
		this.students = students;
	}*/
	public Department(int deptNo, String deptName, LinkedList<Student> students) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.students = students;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Department [deptNo=" + deptNo + ", deptName=" + deptName
				+ ", students=" + students + "]";
	}
	
	public Student getStudent(int regNo){
		Student std=new Student();
		for(Student s: students){
			if(s.getRegNo()==regNo){
				std=s;
				break;
			}
		}
		return std;
	}
	public Student updateStudent(int regNo,String name){
		Student s=new Student();
		s=getStudent(regNo);
		s.setName(name);
		return s;
	}
	public boolean searchStudent(int regNo){
		boolean searchStatus=false;
		//searchStatus=students.contains(getStudent(regNo));
		Iterator<Student> it=students.iterator();
		while(it.hasNext()){
			if(it.next().getRegNo()==regNo){
				searchStatus=true;
				break;
			}
		}
		return searchStatus;
	}
	public void setStudents(LinkedList<Student> students) {
		this.students = students;
	}
	
	public boolean removeStudent(int regNo){
		boolean removeStatus=false;
		Student s=getStudent(regNo);
		students.remove(s);
		removeStatus=true;
		return removeStatus;
	}
	public LinkedList<Student> getStudents() {
		return students;
	}
}
