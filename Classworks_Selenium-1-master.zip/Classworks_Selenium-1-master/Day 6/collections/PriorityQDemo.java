package com.htc.corejava.day6.collections;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQDemo {

	public static void main(String[] args) {
		PriorityQueue<String> prior=new PriorityQueue<>();
		prior.offer("Mango");
		prior.offer("Apple");
		prior.offer("Pomogranite");
		prior.offer("PineApple");
		
		Iterator<String> itr=prior.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		System.out.println("=====================");
		System.out.println(prior.poll());
		
	}
}
