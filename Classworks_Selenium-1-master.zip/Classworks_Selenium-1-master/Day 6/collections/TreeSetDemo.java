package com.htc.corejava.day6.collections;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		
		Set<Trainer> trainer=new TreeSet<>(new Comparator<Trainer>(){

			@Override
			public int compare(Trainer trainer1, Trainer trainer2) {
				/*int result=0;
				if(trainer1.getTrainerId()>trainer2.getTrainerId()){
					result=1;
				}
				else if(trainer1.getTrainerId()<trainer2.getTrainerId()){
					result=-1;
				}*/
				return trainer1.compareTo(trainer2);
			}
			
		});
		trainer.add(new Trainer(12,"JavaTrainer","Java"));
		trainer.add(new Trainer(2,"VBTrainer","Visual Basic"));
		trainer.add(new Trainer(24,"TestingTrainer","Testing"));
		trainer.add(new Trainer(62,"SQLTrainer","SQL"));
		
		for(Trainer t: trainer){
			System.out.println(t);
		}
		
		/*TreeSet<String> tr=new TreeSet<>();
		tr.add("List");
		tr.add("Set");
		tr.add("ArrayList");
		tr.add("Queue");
		tr.add("HashSet");
		
		Iterator<String> itr=tr.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}*/
	}
}
