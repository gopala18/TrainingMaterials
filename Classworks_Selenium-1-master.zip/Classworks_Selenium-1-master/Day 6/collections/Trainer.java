package com.htc.corejava.day6.collections;

public class Trainer implements Comparable<Trainer>{

	private int trainerId;
	private String name;
	private String skill;
	public Trainer(int trainerId, String name, String skill) {
		super();
		this.trainerId = trainerId;
		this.name = name;
		this.skill = skill;
	}
	public Trainer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Trainer [trainerId=" + trainerId + ", name=" + name
				+ ", skill=" + skill + "]";
	}
	public int getTrainerId() {
		return trainerId;
	}
	public void setTrainerId(int trainerId) {
		this.trainerId = trainerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	
	
	@Override
	public int compareTo(Trainer trainer) {
		int compareResult=0;
		if(this.getTrainerId()>trainer.getTrainerId()){
			compareResult=1;
		}
		else if(this.getTrainerId()<trainer.getTrainerId()){
			compareResult=-1;
		}
		return compareResult;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + trainerId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trainer other = (Trainer) obj;
		if (trainerId != other.trainerId)
			return false;
		return true;
	}
	
	
}
