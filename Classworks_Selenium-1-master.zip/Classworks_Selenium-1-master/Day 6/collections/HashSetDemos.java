package com.htc.corejava.day6.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class HashSetDemos {

	public static void main(String[] args) {
/*		HashSet<String> hs=new HashSet<>();
		hs.add("B");
		hs.add("A");
		hs.add("F");
		hs.add("S");
		hs.add("C");
		//System.out.println(hs.add("C"));
		for(String s: hs){
			System.out.println(s);
		}*/
		ArrayList<Trainer> trainer=new ArrayList<>();
		
		trainer.add(new Trainer(12,"JavaTrainer","Java"));
		trainer.add(new Trainer(2,"VBTrainer","Visual Basic"));
		trainer.add(new Trainer(24,"TestingTrainer","Testing"));
		trainer.add(new Trainer(2,"SQLTrainer","SQL"));
		
		Set<Trainer> trainerSet=new HashSet<>();
		trainerSet.addAll(trainer);
		
		for(Trainer t: trainerSet){
			System.out.println(t);
		}
		


		
	}
}
