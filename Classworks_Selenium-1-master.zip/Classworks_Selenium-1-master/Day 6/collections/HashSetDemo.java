package com.htc.corejava.day5.collections;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
		
		HashSet<Integer> hs=new HashSet<>();
		
		hs.add(new Integer(100));
		hs.add(new Integer(10));
		hs.add(new Integer(200));
		hs.add(new Integer(23));
		hs.add(new Integer(53));
		for(Integer in:hs){
			
			System.out.println(in+" HashCode:"+in.hashCode());
		}
		
	}
}
