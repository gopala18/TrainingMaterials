package com.htc.corejava.day5.collections;

public class Student {

	private int regNo;
	private String Name;
	public int getRegNo() {
		return regNo;
	}
	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Student(int regNo, String name) {
		super();
		this.regNo = regNo;
		Name = name;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [regNo=" + regNo + ", Name=" + Name + "]";
	}
	
	
}
