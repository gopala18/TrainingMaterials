package com.htc.corejava.day6.collections;

import java.util.ArrayDeque;
import java.util.Iterator;

public class ArrayDequeDemo {

	public static void main(String[] args) {
		ArrayDeque<Integer> arrayDeque=new ArrayDeque<Integer>();
		arrayDeque.push(new Integer("122"));
		arrayDeque.push(new Integer("12"));
		arrayDeque.push(new Integer("22"));
		arrayDeque.push(new Integer("152"));
		
		/*for(Integer i:arrayDeque){
		System.out.println(i);
		}*/
		Iterator<Integer> itr=arrayDeque.descendingIterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}
