package com.htc.suite;

import org.junit.Assert;		
import org.junit.Test;		

public class SuiteTest2 {				
    /** Test of setEmpName() method, of class Employee */		

    @Test		
    public void createAndSetName() {					
        Employee emp=new Employee();					

        emp.setEmpID(123);					
        emp.setEmpName("Gopi");
        String expected = "Gopi";					
        String actual = emp.getEmpName();					

        Assert.assertEquals(expected, actual);
        System.out.println("Message from the last test Suite");
        System.out.println("Suite Test 1 is successful " + actual);							
    }		

}		