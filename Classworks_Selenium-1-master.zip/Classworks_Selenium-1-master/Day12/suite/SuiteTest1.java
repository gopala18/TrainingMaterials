package com.htc.suite;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class SuiteTest1 {				

    						

    
    @Test(expected = ArithmeticException.class)					
    public void testArithmeticException() {					
    	System.out.println("from suite:1 Test1:ArithmeticException");
    	int result=10/0;
    	
     }		

    @Test(timeout=1000)
    
    public void testJUnitHiMessage() {					
        assertEquals("Junit", "Junit");							
        System.out.println("from suite:1: Test2");
    }		
}		