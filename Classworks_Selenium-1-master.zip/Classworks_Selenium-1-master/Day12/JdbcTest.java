package com.htc.jdbc.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.htc.jdbc.connector.DBConnector;
import com.htc.jdbc.dto.MobileDTO;

public class JdbcTest {
	static Connection con;
	/*@BeforeClass
	public static void createConnection() throws SQLException {
		System.out.println("Before Class");
		con=DBConnector.getConnection();
		
	}*/

	@Before
	public void beforeMethod() throws SQLException {
		System.out.println("Before @Test method");
		con=DBConnector.getConnection("postgres", "123Welcome");
	}
	
	@Test
	public void testInsert() throws SQLException {
		System.out.println("inside testInsert");
		MobileDTO newMobile=new MobileDTO(32323,"express","Lenovo",1000);
		PreparedStatement ps = con.prepareStatement("INSERT INTO Mobile(IEMI,model,brand,cost) VALUES(?,?,?,?)");
		ps.setInt(1, newMobile.getIEMI());
		ps.setString(2, newMobile.getModel());
		ps.setString(3, newMobile.getBrand());
		ps.setDouble(4, newMobile.getCost());
		ps.execute();
	}
	@Test
	public void testDelete() throws SQLException {
		System.out.println("inside testDelete");
		PreparedStatement ps = con.prepareStatement("DELETE FROM Mobile WHERE IEMI=?");
		ps.setInt(1, 32323);
		ps.execute();
	}
	@After
	public void afterMethod() throws SQLException {
		System.out.println("after @Test method");
		con.close();
	}
}
