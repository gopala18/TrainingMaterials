package com.htc.junit;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class JunitSample1 {

	@BeforeClass
	public static void befclass() {
		System.out.println("Before class is .....");
	}

	@AfterClass
	public static void afclass() {
		System.out.println("After class is.....");
	}

	@Before
	public void kickStart() {
		System.out.println("The test is kickstarting");
	}

	@Test
	public void divideByZero() {
		MyClass tester = new MyClass();
		Assert.assertEquals("Testing message: ", 3, tester.multiply(1, 2));
		Assert.assertEquals(0, tester.multiply(10, 0));
		assertEquals(0, tester.multiply(0, 10));
		assertEquals(0, tester.multiply(0, 0));
	}

	@After
	public void closeall() {
		System.out.println("The test is closing");
	}
}