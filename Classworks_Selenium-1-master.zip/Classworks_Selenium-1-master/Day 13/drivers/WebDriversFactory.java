package com.htc.selenium.drivers;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;




public class WebDriversFactory {
	
	public static WebDriver getWebdriver(String browserType) {
	
		WebDriver driver=null;
		
		if(browserType.equalsIgnoreCase("chrome")) {
			System.out.println("Chrome driver");
			System.setProperty("webdriver.chrome.driver", "D:\\AP Training\\Selenium\\chromedriver.exe");
			driver=new ChromeDriver();
			
		}else if(browserType.equalsIgnoreCase("firefox")) {
			System.out.println("Firefox driver");
			System.setProperty("webdriver.gecko.driver", "D:\\AP Training\\Selenium\\geckodriver.exe");
			driver=new FirefoxDriver();
			
		}else if(browserType.equalsIgnoreCase("ie")) {
			System.out.println("IE driver");
			System.setProperty("webdriver.ie.driver", "D:\\AP Training\\Selenium\\IEDriverServer.exe");
			driver=new InternetExplorerDriver(); 
		}else {
			driver=new HtmlUnitDriver(true);
		}
			
		
		return driver;
	}

	
}
