package com.htc.selenium.drivers;


	import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class WebDriverDemo {
 
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = WebDriversFactory.getWebdriver("html");
		
		 		 
		String URL = "http://www.google.com";
		driver.get(URL);
		//driver.navigate().to(URL);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(5000);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		
		/*WebElement searchBar=driver.findElement(By.id("lst-ib"));
		System.out.println(searchBar.isEnabled());
		System.out.println(searchBar.isSelected());
		searchBar.sendKeys("Selenium");
		
		WebElement searchButton=driver.findElement(By.name("btnk"));
		searchButton.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());*/
		//driver.close();		
		//driver.quit();
	}
}