package com.htc.day1.testng;


import org.testng.annotations.Test;

public class FirstTestngScript {
	
  @Test
  public void appTest(){
	  
	  System.out.println("Hello test");
  }
  
  @Test
  public void HelloWorldTest()
  {
	  System.out.println("Hey this is my first test");
  }
}
