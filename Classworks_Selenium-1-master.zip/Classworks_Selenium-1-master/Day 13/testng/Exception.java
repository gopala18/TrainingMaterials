package com.htc.day1.testng;


import java.io.IOException;

import org.testng.annotations.Test;

public class Exception {

	@Test(expectedExceptions = { IOException.class }, expectedExceptionsMessageRegExp = "Pass Message test")
    public void exceptionTestOne() throws IOException {
        throw new IOException("Pass Message test");
    }
 
    @Test(expectedExceptions = { IOException.class }, expectedExceptionsMessageRegExp = ".* Message .*")
    public void exceptionTestTwo() throws IOException {
        throw new IOException("Pass Message test");
    }
 
    @Test(expectedExceptions = { IOException.class }, expectedExceptionsMessageRegExp = "Pass Message test")
    public void exceptionTestThree() throws IOException {
        throw new IOException("Fail Message test");
    }
}
