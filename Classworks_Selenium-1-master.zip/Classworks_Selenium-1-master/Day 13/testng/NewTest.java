package com.htc.day1.testng;


import org.testng.annotations.Test;

public class NewTest {
  @Test(invocationCount=10)
  public void f() {
	  System.out.println("Printing..");
  }
  
}
