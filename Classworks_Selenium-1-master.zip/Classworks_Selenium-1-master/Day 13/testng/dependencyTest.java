package com.htc.day1.testng;


import org.testng.Assert;
import org.testng.annotations.Test; 

public class dependencyTest {
	
	 

	 
	@Test
	public void testLogin()
	{
	 
	System.out.println("login done");
	Assert.assertEquals(12, 13);
	 
	}
	 
	@Test(dependsOnMethods={"testLogin"})
	public void testAccount()
	{
	System.out.println("Account has been created");
	 
	}
	 
	@Test(dependsOnMethods={"testAccount"})
	public void testLogout()
	{
	System.out.println("logout");
	 
	}
	
	@Test(enabled=false)
	public void billing()
	{
		System.out.println("in billing");
	}
	 
	@Test(timeOut=8000)
	public void fetchingDetails() throws InterruptedException
	{
		Thread.sleep(5000);
	}
	
	}

