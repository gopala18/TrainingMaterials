package com.htc.day1.testng;

import org.junit.Assert;
import org.testng.annotations.Test;

public class SampleTestClass {

	@Test
  public void testCase1() {
		System.out.println("first testcase");
  }
	
	@Test
	public void testCase2()
	{
		System.out.println("second testcase");
		
		Assert.assertEquals(10, 2);	
		}
	
	@Test 
	public void atestCase3()
	{
		System.out.println("testcas3");
	}
}
