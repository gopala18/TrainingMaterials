package com.htc.day1.testng;


import org.testng.Assert;
import org.testng.annotations.Test;

public class TestngOrder {
  @Test(priority=0,description="This testcase will verify log in functionality")
  public void LoginTestCase() {
	  
	  System.out.println("Logging in");
	  //Assert.assertEquals(12, 13);
  }
  
  
  @Test(priority=1,description="this testcase will add certain items in the basket")
  public void SelectApp() {
	  
	  System.out.println("Products select");
  }
  
 @Test(priority=2,description="this testcase will perform checkout operation")
 //@Test
  public void ACheckout() {
	  
	  System.out.println("Check out");
  }
  @Test
  public void simple()
  {
	  System.out.println("print simple");
  }
}
