package com.htc.corejava.serialize;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Logger;

public class Main {
 
	public static void main(String[] args) throws FileNotFoundException, IOException {
		/*ObjectOutputStream obj=new ObjectOutputStream(new FileOutputStream("Employee.txt"));
		Logger log=Logger.getLogger("com.htc.corejava.serialize.Main");
		
		log.info("Started to serialize...");
		
				
		obj.writeObject(new Employee(123,"Gopi",new Address(123,"street","city")));
		log.info("Object Serialized");
		obj.close();*/
		
		
	}
}
