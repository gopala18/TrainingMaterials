public class StringMatcherTest{

public static void main(String[] arg){

// isTrue method

		System.out.println(m.isTrue("true"));
        System.out.println(m.isTrue("true2"));
        System.out.println(m.isTrue("True"));
		
		
// isTrue overloaded

 System.out.println(m.isTrueVersion2("true"));
        System.out.println(m.isTrueVersion2("true2"));
        System.out.println(m.isTrueVersion2("True"));
		
		// is true or yes
		
		System.out.println(m.isTrueOrYes("true"));
        System.out.println(m.isTrueOrYes("yes"));
        System.out.println(m.isTrueOrYes("Yes"));
        System.out.println(m.isTrueOrYes("no"));
		
		// contains true
		
		System.out.println(m.containsTrue("thetruewithin"));
		
		// is three letters
		
		System.out.println(m.isThreeLetters("abc"));
        System.out.println(m.isThreeLetters("abcd"));
		
		// no number at begining
		
		System.out.println(m.isNoNumberAtBeginning("abc"));
        System.out.println(m.isNoNumberAtBeginning("1abcd"));
        System.out.println(m.isNoNumberAtBeginning("a1bcd"));
        System.out.println(m.isNoNumberAtBeginning("asdfdsf"));
		
		// intersection
		
		 System.out.println(m.isIntersection("1"));
        System.out.println(m.isIntersection("abcksdfkdskfsdfdsf"));
        System.out.println(m.isIntersection("skdskfjsmcnxmvjwque484242"));
		
		// less than 300
		
		 System.out.println(m.isLessThenThreeHundred("288"));
        System.out.println(m.isLessThenThreeHundred("3288"));
        System.out.println(m.isLessThenThreeHundred("328 8"));
        System.out.println(m.isLessThenThreeHundred("1"));
        System.out.println(m.isLessThenThreeHundred("99"));
        System.out.println(m.isLessThenThreeHundred("300"));