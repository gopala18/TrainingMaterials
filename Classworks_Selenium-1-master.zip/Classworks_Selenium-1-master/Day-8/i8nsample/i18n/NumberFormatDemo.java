package com.htc.corejava.day10.i18n;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;

public class NumberFormatDemo {

	public static void main(String[] args) {
		
		DateFormat df1=DateFormat.getDateInstance(DateFormat.SHORT);
		System.out.println(df1.format(new Date()));
		
		double salary=2000000.00;
		System.out.println("Default Locale: "+NumberFormat.getInstance().format(salary));
		//DecimalFormat df=(DecimalFormat)NumberFormat.getInstance().format(salary);
	
		DecimalFormat df=new DecimalFormat();
		df.applyPattern("\u0024 ###,###,###.##");
		System.out.println("Decimal format:"+df.format(salary));
		
		
	}
}
