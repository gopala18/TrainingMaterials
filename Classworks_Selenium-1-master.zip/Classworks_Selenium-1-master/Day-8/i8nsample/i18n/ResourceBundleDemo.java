package com.htc.corejava.day10.i18n;

import java.util.ResourceBundle;

public class ResourceBundleDemo {

	public static void main(String[] args) {
		ResourceBundle rb=ResourceBundle.getBundle("ApplicationResources");
		
		//System.out.println(rb.getKeys());
		System.out.println(rb.getString("goodmorning"));
		System.out.println(rb.getString("thankyou"));
	}
}
