package com.htc.corejava.day10.i18n;

import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class UnicodeDemo extends JFrame{
	public UnicodeDemo(){
		
		JLabel label = new JLabel("Your Name");
		JTextField t1 = new JTextField(25);
		String name = "\u0B85\u0BAE\u0BCD\u0BAE\u0BBE";
		t1.setFont(new Font("Latha", Font.BOLD, 16));
		t1.setText(name);
		
		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(label);
		getContentPane().add(t1);
		
		setVisible(true);
		setSize(500, 500);
		setTitle("Tamil Font");
		
	}
	
	public static void main(String[] args) {
		new UnicodeDemo();
	}
	

}
