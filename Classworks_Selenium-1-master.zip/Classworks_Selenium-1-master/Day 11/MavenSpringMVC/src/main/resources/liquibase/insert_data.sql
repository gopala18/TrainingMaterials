--liquibase formatted sql
--changeset Gopi Muruganantham:release_1.insert_data.sql

INSERT INTO users VALUES ('Anish','123Welcome','Anish','kumar','anish!@htcindia.com','Chennai',123456987);


INSERT INTO users VALUES ('Gopi','password','Gopi','Muruganantham','gopi.officials@gmail.com','Chennai',123456789);


INSERT INTO users VALUES ('sayooj','123Welcome','sayooj','panakal','sayoojp@htcindia.com','Chennai',123456);

