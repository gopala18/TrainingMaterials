package arrays;

public class ArrayDemo {

	public static void main(String[] args) {
		int empID[]=new int[200];
		empID[0]=123;
		
		for(int i=0;i<20;i++){  // assign value
			empID[i]=i+100;
			
		}
		
		for(int i=0;i<20;i++){   //reteive value
			System.out.println(empID[i]);
		}
		
	}
}
