package arrays;

public class ArrayDecl {
	public static void main(String[] args) {
		int a1[]=new int[5];
		int a2[]=new int[]{1,2,3,4,5};
		int a3[]={1,2,3,4,5};
		
		int a[/* 2 */] = { 1, 2 }; // donot specify size when declaring explicitly
		
		String expectedList[]=new String[]{" - Select a Choice - ","Yes","No"};
		String expectedList1[]={" - Select a Choice - ","Yes","No"};

		String anb = "1,,,,,,";
		String anbArray[] = anb.split(",");
		System.out.println(anbArray.length);
		
		for (String str : anbArray)
			System.out.println(str);
		
		anb = "1,2,,,,,";
		String anbArray1[] = anb.split(",");
		System.out.println(anbArray1.length);
		
		anb = ",,,,,";
		String anbArray2[] = anb.split(",");
		System.out.println(anbArray2.length);
	}
}

/*
splitting is done on the REGEX EXPRESSION, elements must be present between those regex to be added to array
output of "1,,,,,," will not be [1,{,,,,}]. ie it will not be of length 2
*/