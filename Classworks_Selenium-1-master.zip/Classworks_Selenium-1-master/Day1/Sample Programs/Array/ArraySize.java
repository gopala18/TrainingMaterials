package arrays;

public class ArraySize {

	
	public static void main(String[] args) {
		int a[]=new int[5];
		
		//The length will be always 15, no matter how many indexes are filled.
		//Because array size is fixed, you do not have any inbuilt method to check its logical size
		//If we actually need to keep a tab on the actual length then we need to set a COUNTER for each ADDITION
		
		
		//It will always have default values, whether its declared locally or globally.
		System.out.println(a[0]);
		
	}
	
}


/**

Arrays are special objects in java, they have a simple attribute named length which is final.

There is no "class definition" of an array (you can't find it in any .class file), 
they're a part of the language itself.

Array Members
The members of an array type are all of the following:

The public final field length, which contains the number of components of the array.
length may be positive or zero.

*/