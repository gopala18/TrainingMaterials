package conditions;

public class IfElseBreak {
public static void main(String[] args) {
	int a=5;
	int b=5;
	if(true)
	{
		if(a==5)
		{
			System.out.println("first if");

		}
		else if(b==5)
		{
			System.out.println("first if");
		}
	}
}
}
