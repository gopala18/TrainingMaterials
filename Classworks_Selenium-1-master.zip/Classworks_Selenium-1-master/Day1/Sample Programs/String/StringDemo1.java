package strings;

public class StringDemo1 {

	public static void main(String[] args) {
		String str="java";
		String str1=new String("JAVA");
		
		System.out.println(str);
		System.out.println(str1);
		if(str.equals(str1)){
			System.out.println("true");
		}else
			System.out.println("false");
		
		
		if(str.equalsIgnoreCase(str1)){
			System.out.println("true");
		}else
			System.out.println("false");
		
		System.out.println(str1.charAt(3));
		System.out.println(str.length());
		System.out.println(str.concat(" Programming"));
		System.out.println(str.isEmpty());
		
		
		
	}
}
