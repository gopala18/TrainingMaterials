class ConditionalOperator {
    public static void main(String[] args) {
    	
    	int februaryDays = 29;
    	String result;
    	
    	result =  (februaryDays == 28) ? "Not a leap year" : "Leap year";
    	System.out.println(result);
    }
}