package operators;

public class PrePostincrement {

	public static void main(String arg[]) {

		int a = 1;
		int b = a++;
		int c = ++a;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println();

		a = 1;
		System.out.println(a++);
		System.out.println(a);
		System.out.println(++a);
		System.out.println();

		a = 0;
		b = 1 + a++;
		System.out.println(b);

		a = 0;
		b = a++ + ++a;
		System.out.println("a++ + ++a : " + b);

		a = 0;
		b = a++ + a++ + ++a;
		System.out.println("a++ + a++ + ++a : " + b);

		a = 2;
		a *= 2 + 5;
		System.out.println(a);

	}

}
