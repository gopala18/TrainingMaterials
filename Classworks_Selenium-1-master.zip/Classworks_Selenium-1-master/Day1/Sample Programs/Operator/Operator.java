package operators;

public class Operator {

	public static void main(String[] args) {

		int age =17;
		String name ="Gopi";
		String city="Chennai";
		
		if(age>18){  // simple if statement
			
			//functional unit of code for this condition
			System.out.println("Eligible for Polling");
		}
		
		if(age>18){   // if-else
			System.out.println("Eligible for polling");
		}else{
			System.out.println("Not eligible for Polling");
		}
		
		
		if(age>18){ // else-if ladder
			System.out.println("Eligible for polling");
		}else if(city.equals("Chennai")){
			System.out.println("Eligible for polling");
		}
		
		
		
	}
}
