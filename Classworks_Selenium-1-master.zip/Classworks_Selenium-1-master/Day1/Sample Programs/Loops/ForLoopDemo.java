package conditions;

public class ForLoopDemo {

	public static void main(String[] args) {
		
		int A=10;
		for(int a=0;a<100;a++){
			System.out.println(a);
		}
		
		while(true){   //entry control loop
			//statement
			System.out.println("Hello");
			break;
		}
		
		do{   //exit control loop
			System.out.println("Value of A:"+A);
		}while(A>10);
		
	}
}
