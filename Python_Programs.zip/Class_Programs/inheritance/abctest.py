'''
Created on 17-Jan-2017

@author: Sayooj
'''
import abc

class employeedao:
    __metaclass__ = abc.ABCMeta
    
    @abc.abstractmethod
    def insertemp(self, employee):
        """ This will insert an employee object in the database"""
        return
    
    @abc.abstractmethod
    def getemployee(self, empno):
        """ This will retrieve an employee object from database for the given empno"""
        return
    
class employeedaoimpl(employeedao):
     
    def insertemp(self, employee):
        print "Inserting employee to database"
        return True
     
    def getemployee(self, empno):
        print "Retrieved an employee object"
        return True
    