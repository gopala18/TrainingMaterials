'''
Created on 17-Jan-2017

@author: Sayooj
'''

class emp:
    
    def __init__(self, empno, empname, salary):
        self.empno = empno
        self.empname = empname
        self.salary = salary
        
    def getattr(self, field):
        print "From Employee"
        if field == "empno":
            return self.empno
        elif field == "empname":
            return self.empname
        else:
            return self.salary
    
    def __str__(self):
        return str(self.empno) +"," + str(self.empname) + "," + str(self.salary)    
    
    def __repr__(self):
        return str(self.empno) +"," + str(self.empname) + "," + str(self.salary)    
    
class manager(emp):    
    
    def __init__(self, empno, empname, salary, commission):
        emp.__init__(self, empno, empname, salary)
        print(commission)
        self.commission = commission
        
    def getattr(self, field):       # overriding getattr() method
        if field == "empno":
            return self.empno
        elif field == "empname":
            return self.empname
        else:
            print "From manager"
            return self.salary + self.commission

    def __repr__(self):
         print('repr')
         return str(self.empno) +"," + str(self.empname) + "," + str(self.salary) + "," +  str(self.commission)
    
    def __str__(self):
        print('str')
        return str(self.empno) +"," + str(self.empname) + "," + str(self.salary) + ","+  str(self.commission)#return str(self.empno) +"," + str(self.empname) + "," + str(self.salary) +","+str(self.commission)
        
    
class developer(emp):

    def __init__(self, empno, empname, salary, pallowance, otallowance):
        emp.__init__(self, empno, empname, salary)
        self.projectallowance = pallowance
        self.overtimeallowance= otallowance
        
    def getattr(self, field):       # overriding getattr() method
        if field == "empno":
            return self.empno
        elif field == "empname":
            return self.empname
        else:
            print "From Developer"
            return self.salary + self.overtimeallowance + self.projectallowance 
        
    def __str__(self):
        print('str')
        return str(self.empno) +"," + str(self.empname) + "," + str(self.salary) + ","+  str(self.overtimeallowance)+ ","+  str(self.projectallowance)   
    def __repr__(self):
        print('str')
        return str(self.empno) +"," + str(self.empname) + "," + str(self.salary) + ","+  str(self.overtimeallowance)+ ","+  str(self.projectallowance)   
        
class dept:
    
    
    def addEmployee(self, employee):
        self.employees.append(employee)
        
    def getsalary(self, empno):
        sal = 0;
        for e in self.employees:
            if e.getattr("empno") == empno:
                sal = e.getattr("salary")
                break
        return sal    
        
    def __str__(self):
        return str(self.employees)
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        