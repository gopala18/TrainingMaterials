'''
Created on Oct 25, 2017

@author: bhavanik
'''
from abc import ABCMeta,abstractmethod
from _pyio import __metaclass__

#interface
class Shape(object):
    __metaclass__=ABCMeta

    @abstractmethod
    def area(self):pass
    
    @abstractmethod 
    def perimeter(self):pass
        
        
        
        
class Rectangle(Shape):         
  
    def __init__(self,width,height):
        self._width=width
        self._height=height
        
        super(Rectangle,self).__init__()
        
  
    def area(self):
        return self._width*self._height
  
  
    
    def perimeter(self):
        return self._width*self._height*2
  
   
s=Rectangle(3.4,5)
print s.area()
        