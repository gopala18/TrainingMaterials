'''
Created on Oct 24, 2017

@author: bhavanik
'''

from abc import ABCMeta,abstractmethod
from _pyio import __metaclass__
from classes.psConn import DbConnect
from psycopg2.psycopg1 import cursor




class Product(object):

    def __init__(self,productId=0,productDesc="",price=0.0):      
        self._productId=productId
        self._productDesc=productDesc
        self._price=price
        
    
    
    def getattr(self,attrName):
        
        if attrName=="_productId":
            return self._productId
         
        elif attrName=="_productDesc":
            return self._productDesc
        else:
            return self._price 
        

    def setattr(self,attrName,attrVal):
        
        if attrName=="_productId":
            self._productId=attrVal
         
        elif attrName=="_productDesc":
            self._productName=attrVal
        else:
            self._price=attrVal
            
            
    def getTotal(self,quantity): 
            return getattr(self, "_price")*quantity
        
        
        
    def __repr__(self):
        return   "productId-{}, productName-{},  price-{}".format(self._productId, self._productDesc, self._price)        
        
     
     
 #interface   
class ProductDAO(object):
    __metaclass__=ABCMeta
    
    @abstractmethod
    def storeProduct(self,Product):
        pass
     
        ''' @abstractmethod   
    def updateProduct(self,prod_id,price):
        pass
    @abstractmethod    
    def deleteProduct(self,prod_id):
         pass
    @abstractmethod
    def getProduct(self,prod_id):
        pass'''

        
            
   
   
class ProductDAOImpl(ProductDAO):
    
    def __init__(self):
        
         super(ProductDAOImpl,self).__init__()
    
    def storeProduct(self,Product): 
        Conn=DbConnect.getConnection()
        print(Conn)
        Cursor=Conn.cursor();
        Cursor.execute("insert into product_sample values ('%s','%s',%d)" % (Product.getattr("_productId"),Product.getattr("_productDesc"),Product.getattr("_price")))
        Conn.commit()
        print "value inserted successfully"
        Conn.close()
        
                