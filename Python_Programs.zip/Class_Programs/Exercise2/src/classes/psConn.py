'''
Created on Oct 26, 2017

@author: bhavanik
'''

import psycopg2

class DbConnect:
    @staticmethod
    def getConnection():
        try:
              conn = psycopg2.connect("dbname='sample_db' user='postgres' host='172.16.50.14' password='password@123'")
             
        except:
              print("Unable to connect to database")
        return conn                 