'''
Created on Oct 24, 2017

@author: bhavanik
'''

import classes
'''from classes.Product import ProductDAOImpl'''

p1 = classes.Product(101,"PEN",05.50)
setattr(p1,"_productDesc", "pencil")
print p1

dao= classes.Product.ProductDAOImpl()
dao.storeProduct(p1)
