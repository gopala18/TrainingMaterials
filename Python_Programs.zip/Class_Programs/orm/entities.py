'''
Created on 30-Jan-2017

@author: Sayooj
'''
from sqlalchemy.ext.declarative.api import declarative_base
from sqlalchemy.sql.schema import Column, ForeignKey
from sqlalchemy.sql.sqltypes import Integer, String, Float, DateTime
from sqlalchemy.orm import relationship, backref


Base = declarative_base();

class department(Base):
    __tablename__ = "dept"
    
    deptno = Column("deptno", Integer, primary_key=True)
    deptname = Column("deptname", String)

    employees = relationship("employee")
        
    def __repr__(self):
        return "department ["+ str(self.deptno) + "," + self.deptname + "]"

    
class employee(Base):
    __tablename__ = "employee"
    empno = Column("empno", Integer, primary_key=True)
    empname= Column("empname", String)
    salary = Column("salary", Float)
    job = Column("job", String)   
    joindate  = Column("hiredate", DateTime)
    deptno = Column("deptno", Integer, ForeignKey("dept.deptno"))

    def __repr__(self):
        return "employee [" + str(self.empno) + "," + self.empname + "," + str(self.salary) + ","+ self.job + ","+ str(self.joindate) + "," + str(self.deptno) + "]"
    
    
     