'''
Created on 30-Jan-2017

@author: Sayooj
'''
from orm.empmgmtservice import employeeservice
import datetime


empservice = employeeservice()
#print empservice.insertdept(department(deptno=20, deptname="Admin"))

#print empservice.insertemp(employee(empno=102,empname="Anil",salary=6000.0, job="Programmer", joindate=datetime.date.today(), deptno=10))

dept = empservice.getdept(10)
print dept
print dept.employees

#emp = empservice.getemployee(10)
#print emp