from orm.entities import department, employee
from orm.empmgmtservice import employeeservice