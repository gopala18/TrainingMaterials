'''
Created on 30-Jan-2017

@author: Sayooj
'''
from sqlalchemy.engine import create_engine
from sqlalchemy.orm.session import sessionmaker
from orm.empdao import employeedao

engine = create_engine("postgresql+psycopg2://postgres:123Welcome@localhost/postgres")
DBSession = sessionmaker(bind=engine)

class employeeservice:
    
    def insertdept(self, dept):
        session = DBSession()
        empdao = employeedao()
        insertflag = empdao.insertdept(dept, session)
        if insertflag == True:
            session.commit()
        else:
            session.rollback()
        session.close()
        return insertflag 
    
    def insertemp(self, emp):
        session = DBSession()
        empdao = employeedao()
        insertflag = empdao.insertemp(emp, session)
        if insertflag == True:
            session.commit()
        else:
            session.rollback()       
        session.close()
        return insertflag 
    
    def getdept(self, deptno):
        session = DBSession()
        empdao = employeedao()
        dept = empdao.getdept(deptno, session)
        session.close()
        return dept 

    def getemployee(self, empno):
        session = DBSession()
        empdao = employeedao()
        emp = empdao.getemployee(empno, session)
        session.close()
        return emp 
            