'''
Created on 30-Jan-2017

@author: Sayooj
'''
import logging
from pack.orm.entities import department, employee

class employeedao:
    
    def insertdept(self, dept, session):
        insertflag = False
        try:
            session.add(dept)
            insertflag = True
        except Exception  as ex:
            logging.error(ex)
        return insertflag
    
    def getdept(self, deptno, session):
        dept = None
        try:
            qry = session.query(department).filter(department.deptno == deptno)
            dept = qry.one()
        except Exception as ex:
            logging.error(ex)
        return dept
        
    def insertemp(self, emp, session):
        insertflag = False
        try:
            session.add(emp)
            insertflag = True
        except Exception  as ex:
            logging.error(ex)
        return insertflag

    def getemployee(self, empno, session):
        emp = None
        try:
            qry = session.query(employee).filter(employee.empno == empno)
            emp = qry.one()   #return a single object / error
        except Exception as ex:
            logging.error(ex)
        return emp
        
        