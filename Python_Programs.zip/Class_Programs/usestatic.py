'''
Created on 16-Jan-2017

@author: Sayooj
'''

import objects

cust = objects.customer();
print cust
print objects.customer.getcustomercount()

cust1 = objects.customer("HTC", "Chennai", "49595959")
print objects.customer.customer_count

