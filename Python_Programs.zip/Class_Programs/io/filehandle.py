'''
Created on 18-Jan-2017

@author: Sayooj
'''
import os

filew = open("d:/python.txt", "w")
filew.write("This is a test file\n")
filew.write("This is to test file handling in python\n")
filew.write("This is a end line\n")
filew.close();
print "File created"

file = open("d:/puthon.txt", "r")
lines = file.readlines()
for line in lines:
    print line
file.close()

print "----------------"


file = open("d:/python.txt", "r")
print file.tell()
file.readline()
print file.tell();
file.close();

print "----------------"
file = open("d:/python.txt", "r+")
print file.tell()
file.seek(21)
file.write("HTC")
print file.tell()
file.close();

print "Filesize:" , os.path.getsize("d:/python.txt")
root="d:\\"
print os.path.join(root,"python", "documents")

print os.path.sep   # File.seperator

