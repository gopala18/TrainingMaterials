'''
Created on 17-Jan-2017

@author: Sayooj
'''

 
class NameNotFoundError(Exception):
    
    """ NameNotFoundError exception class"""
    def __init__(self, erromessage="Name Not Found"):
        self.errormessage = erromessage
        
    def __str__(self):
        return self.errormessage
    

def testexceptionmethod(index):
    namelist = ["dhoni", "sachin", "raja", "raina"]
    if namelist.__len__() >= index:
        name = namelist[index]
        print name
    else:
        raise IndexError("Wrong Index")    

def searchname(name):
    namelist = ["dhoni", "sachin", "raja", "raina"]
    if name in namelist:
        return True
    else:
        raise NameNotFoundError()
    

def teststandarderror():    
    try:
        testexceptionmethod(5)
    except IndexError as idx:
        print "Invalid Index", idx
    else:
        print "Successfully completed"
    finally:
        print "Always executes" 
    
def testuserdefinederror():
    try:
        print searchname("suresh")
    except NameNotFoundError as nmerr:
        print nmerr
        
testuserdefinederror()
print "--------------------"
teststandarderror()        