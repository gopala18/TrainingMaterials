'''
Created on 19-Jan-2017

@author: Sayooj
'''

import pickle

class user:
    
    def __init__(self, userid, username, password, email):
        self.userid = userid
        self.username = username
        self.password = password
        self.email = email
    
    def __repr__(self):
        return self.userid + "," + self.username + "," + self.password + "," + self.email
    '''
    def __getstate__(self):   # list, tuple, dict
        return (self.userid, self.username, self.email)
    
    def __setstate__(self, usertuple):
        self.userid = usertuple[0]
        self.username = usertuple[1]
        self.email = usertuple[2]
        self.password = '############'
    '''
    def __getstate__(self):
        cloneddict = self.__dict__.copy()  # shallow copy
        del cloneddict["password"]
        return cloneddict

    def __setstate__(self, userdict):
        self.userid = userdict["userid"]
        self.username = userdict["username"]
        self.email = userdict["email"]
        self.password = "&&&&&&&&&&&&&"
        
u = user("u0001","Ravi", "ravvi1234","ravi@htcindia.com")

pickleduser = pickle.dumps(u)
print pickleduser
print "Pickled"
print "Unpickling"
print pickle.loads(pickleduser)

print "============================================================="
# Pickle to a file.

try:
    userfl = open("user.dat", "wb")
    pickle.dump(u, userfl)
    print "Pickled to user file"    
except Exception as ex:
    print ex
finally:
    if not userfl.closed:
        userfl.close()        

# unpickle from a file.
try:
    userfl = open("user.dat", "rb")
    userobj = pickle.load(userfl)
    print userobj    
except Exception as ex:
    print ex
finally:
    if not userfl.closed:
        userfl.close()        
    