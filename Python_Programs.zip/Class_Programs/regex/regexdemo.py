'''
Created on 18-Jan-2017

@author: sayooj
'''

import re

phone ="987vvv6666567"
matchresult = re.match("[0-9]{10}", phone)
if matchresult is None:
    print "Match Failed"
else:
    print "Phone no. Input Success"
    


emailpattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";    
matchresult = re.match(emailpattern, "ravi_htc@htcindia.com")
if matchresult is None:
    print "Match Failed"
else:
    print "Email Input Success"


cardno = "4556-4456-4434-7488"
cardpattern = "[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}[-]{1}[0-9]{4}"

matchresult = re.match(cardpattern, cardno)
if matchresult is None:
    print "Match Failed"
else:
    print "Cardno Input Success"

raw_input()
