'''
Created on 24-Jan-2017

@author: Sayooj
'''

LOG_SETTINGS = {
        'version': 1,
        'root': {
            'level': 'INFO',
            'handlers': ['file','console']
            },
        'handlers': {
            'console': {
                'class' : 'logging.StreamHandler',
                'level': 'INFO',
                'formatter': 'simpleformatter'
            },
            'file': {
                'class' : 'logging.FileHandler',
                'level' : 'WARNING',
                'formatter' : 'simpleformatter',
                'filename': 'dictlog.log',
                'mode' : 'a'
            }     
        },
        'formatters': {
            'simpleformatter' : {
                'format' : '%(asctime)s %(module)-17s line: %(lineno)-4d %(levelname)-8s %(message)s',
            }
        }            
    }