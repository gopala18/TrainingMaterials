'''
Created on 24-Jan-2017

@author: Sayooj
'''

import dictlogconfig
import logging.config

logging.config.dictConfig(dictlogconfig.LOG_SETTINGS)

logging.info("Information message")
logging.warning("Warning message")
logging.error("Error message")



