'''
Created on 23-Jan-2017

@author: Sayooj
'''

# Programmatic configuration of loggers

import logging

logger = logging.getLogger(__name__)

logger.setLevel(logging.ERROR)

cnhandler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s : %(message)s')
cnhandler.setFormatter(formatter)
logger.addHandler(cnhandler)

logger.log(logging.INFO, "This is to test Logging in python")
logger.info("Information message")
logger.warning("This is a warning message")
logger.critical("This critical error")
logger.error("Error occured")

#===================================================

logger2 = logging.getLogger("filelogger")
logger.setLevel(logging.INFO)

fh = logging.FileHandler("mylog.log", "a")
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s : %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)

logger.info("This is information message")
logger.warning("Warning message")
logger.error("Error message")
