'''
Created on 11-Jan-2017

@author: sayooj
'''

num = 10
counter = 1
while (counter <= num):
    print counter
    if counter == 5:
        break
    counter = counter + 1
print "End Loop"
print("\n")

choice = True
incr = 1
while choice:
    print incr
    incr = incr + 1;
    if incr == 5:
        break

print "For Loop"
for i in range(10):
    print i
    
for ch in "HTC GLOBAL SERVICES":
    print ch
    
    searchElement = 20
found = False
for elem in [10, 20, 30, 40, 50]:
        if searchElement == elem:
            found = True
print found   

     