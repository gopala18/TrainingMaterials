'''
Created on 11-Jan-2017

@author: sayoojp
'''


def addNumber(num1, num2= 100):
    "To add two numbers"
    total = num1 + num2
    return total;

def replaceListElement(myList):
    myList[0] = 1000
    return

def getTotalMarks(regno, marks):
    total = 0
    for mark in marks:
        total = total + mark
    return total;

