'''
Created on 11-Jan-2017

@author: Sayooj
'''

print "HelloWorld!"
yourname= ""
yourname = raw_input("Enter your name")  #To take raw input.
print "Your name:", yourname

fname = raw_input("Enter your friend name:")
print fname

mark1 = int(input("Enter mark1"))
print mark1


print "{}, {},  {}".format(yourname, fname, mark1)
print "%-10s %-10s %d" % (yourname, fname, mark1)
print "{1}, {2},  {0}".format(yourname, fname, mark1)

