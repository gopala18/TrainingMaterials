
String1='     this is a test string for string functions     .'

String2='test'

print "Capitalized result  : "+String1.capitalize()

print "Titlecase result : "+String1.title()

print "Search substring result :"+ str(String1.find(String2))

print "String Length : "+ str(String1.__len__())

print "Centered  :"+ String1.center(60)

print "Index of substr : "+ str(String1.index(String2))

print "Is alphanumeric? "+ str(String1.isalnum())

print "Is alphabetic? "+ str(String1.isalpha())

print "Is digits? "+ str(String1.isdigit())

print "Is lowercase? "+ str(String1.islower())

print "Is whitespace? "+ str(String1.isspace())

str = "-";

seq = ("a", "b", "c"); # This is sequence of strings.

print "Join sequence  "+str.join( seq );

print (len(String1))

print "fill with char : "+(String1.ljust(50, '0'));

print String1.lstrip();

str = "this is string example....wow!!!";

print "Max character: " + max(str);
print str.replace("is", "was");

str1 = "this is string example....wow!!!";
str2 = "is";

print str1.rindex(str2);

print str1.index(str2); 








