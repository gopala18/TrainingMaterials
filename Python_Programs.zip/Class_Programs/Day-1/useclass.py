'''
Created on 12-Jan-2017
@author: Sayooj
'''
import objects

emp = objects.employee(1456, "Rahul", 5000.0)
#print emp.empno     

print emp
print emp.getattr("_empno")
print emp.getempno()


# Using department objects
dept = objects.department("Training")
dept.addemployee(objects.employee(345,"charlie", 25000.0))
dept.addemployee(objects.employee(346,"Harish", 35000.0))
dept.addemployee(objects.employee(347,"vinod", 45000.0))
dept.addemployee(objects.employee(348,"Manu Prasad", 65000.0))

print dept
print dept.removeemployee(347);
print dept


print dept.getemployee(345)

dept.incrementsalary(345, 20000.0)
print dept.getemployee(345)