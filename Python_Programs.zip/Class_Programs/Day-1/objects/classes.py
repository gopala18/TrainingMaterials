'''
    Created on 12-Jan-2017
    @author: Sayooj
'''
class employee(object):
    """ Employee Class"""
     
    def __init__(self, empno = 0, empname="", salary=0.0):   #param constructor
        self._empno = empno
        self._empname = empname
        self._salary = salary
    
    def setempno(self, empno):
        self._empno = empno;
    
    def getempno(self):
        return self._empno
        
    def getattr(self, attrName):
        if attrName == "_empno":
            return self._empno
        elif attrName == "_empname":
            return self._empname
        else:
            return self._salary
        
    def setattr(self, attrName, attrVal):
        if attrName == "_empno":
            self._empno = attrVal
        elif attrName == "_empname":
            self._empname = attrVal
        else:
            self._salary = attrVal
    
    def __repr__(self):
        return   "Empno-{}, Empname-{},  Salary-{}".format(self._empno, self._empname, self._salary)      
    
    
    # Department class
class department(object):
    
    def __init__(self, deptname=""):
        self._deptname = deptname
        self._employees=[]
    
    def addemployee(self, emp):
        self._employees.append(emp)
        
    def removeemployee(self, empno):
        """ remove an employee from the list with the given empno"""
        
        removestatus = False
        for e in self._employees:
            if e.getempno() == empno:
                self._employees.remove(e)
                removestatus = True
                break
        return removestatus
    
    def getemployee(self, empno):
        """ Get an employee with te given empno"""
        emp = None
        for e in self._employees:
            if e.getempno() == empno:
                emp = e
                break
        return emp   
    
    def incrementsalary(self, empno, incrsalary):
        """ Increment the salary of the employee"""
        for e in self._employees:
            if e.getempno() == empno:
                newsalary = e.getattr("_salary") + incrsalary
                e.setattr("salary", newsalary)
                return True
        return False
             
    def __repr__(self):
        return self._deptname + " -[" + str(self._employees) + " ]"
        
                        