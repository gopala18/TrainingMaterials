'''
Created on 11-Jan-2017

@author: Sayooj
'''

result = 10.0//3.0
print result

num = 20;

if num == 10:
    print "First Line"
    print "Second Line"
else:
    print "Outside if"     

if num == 10:
    print "Num 10"
elif num == 20:
    print "Num 20"
    print "Nother statement"
else:
    print "Else part"    
    result = 10.0/3.0
print result
raw_input()
