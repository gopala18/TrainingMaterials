'''
Created on 11-Jan-2017

@author: Sayooj
'''
#from pack.sub import methods
import sub

print sub.addNumber(10, 20)
