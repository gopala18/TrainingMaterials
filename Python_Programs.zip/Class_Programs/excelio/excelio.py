'''
Created on 18-Jan-2017

@author: Sayooj
'''

import openpyxl   # Third party module, Must be installed using 
    #  >> pip  install openpyxl
    
workbook = openpyxl.load_workbook("d:\emp.xlsx",'r')
#workbook.refresh

sheet = workbook["Sheet1"]
print (sheet.max_row)
for row in range(2, sheet.max_row+1):
    empno = sheet["A" + str(row)].value
    empname = sheet["B" + str(row)].value
    salary = sheet["C" + str(row)].value
    deptno = sheet["D" + str(row)] .value
    print (empno, empname, salary, deptno)  
