'''
Created on 16-Jan-2017

@author: Sayooj
'''
import datetime

d = datetime.date.today()
print d

formatteddate = d.strftime("%d-%m-%Y  %H:%M:%S")
print formatteddate;

d = datetime.date(2017, 10, 20)
print d

formatteddate = d.strftime("%d-%m-%Y")
print formatteddate