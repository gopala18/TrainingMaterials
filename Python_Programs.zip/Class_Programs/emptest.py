import inheritance

empobj= inheritance.emp(001, 'Jani',50000)
print empobj

manobj= inheritance.manager(002,'Sam',70000,6000)
print manobj

devobj=inheritance.developer(003,'Kim',80000,7800,3000)
print devobj

deptobj=inheritance.dept()

deptobj.addEmployee(empobj)
deptobj.addEmployee(manobj)
deptobj.addEmployee(devobj)

print deptobj

print deptobj.getsalary(002)

print deptobj.getsalary(003)
 

    