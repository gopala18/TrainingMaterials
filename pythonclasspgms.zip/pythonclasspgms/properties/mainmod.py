'''
Created on 29-Nov-2017

@author: sayoojp
'''
import employee
empobj=employee.employee()
print empobj
print  "Displaying object dictionary", empobj.__dict__
print '\n'
empobj2=employee.employee("Sam",40000)
print("New employee created....")
print '\n'
print empobj2  
'''str displayed by default'''
print '\n'
print empobj2.__repr__()  
print '\n'
print empobj2.__str__() 

print '\n'
empobj3=employee.employee()
print("New employee created....")
empobj3.set_name(raw_input("Enter the name: "))
empobj3.set_salary(raw_input("Enter the salary: "))
#empobj3._employee__name=name
#empobj3._employee__salary=salary
#del empobj3._employee__salary
print empobj3
