'''
Created on 28-Nov-2017

@author: sayoojp
'''
class employee:
   
    def __init__(self,name='default',salary=2000):
        self.__name =name
        self.__salary =salary
   
    '''Generated properties'''''
    def get_name(self):
        print("name get property called")
        return self.__name
    def get_salary(self):
        print("salary get property called")
        return self.__salary
   
    def set_name(self, value):
        print("name set property called")
        #if isinstance(value, str):
        try:
            int(value)
            raise TypeError("Name must be an String")
          
        except ValueError:
                self.__name = value
           
    def set_salary(self, value):
        print("salary set property called")
       
        #if (isinstance(value, float) or isinstance(value, int) ):
        try:
            value=int(value)
            
            if ((value>5000) and (value<50000)):
                self.__salary = value
            else: 
                raise ValueError("Salary must be between 5000 and 50000")
        except TypeError as e:
            print e
            raise TypeError("Name must be a numeric")
            
        
        
    def del_name(self):
        print("name del property called")
        del self.__name
    def del_salary(self):
        print("salary del property called")
        del self.__salary
    def __repr__(self):
        return "From repr .....Name = {} Salary = {}".format(self.__name,self.__salary)
    
    def __str__(self):
        return "From str Name = {} Salary = {}".format(self.__name,self.__salary)

    
    name = property(get_name, set_name, del_name, "name's docstring")
    salary = property(get_salary, set_salary, del_salary, "salary's docstring")
