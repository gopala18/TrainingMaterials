'''
Created on 05-Dec-2017

@author: sayoojp
'''
#!/usr/bin/python3

from openpyxl import Workbook

book = Workbook()
sheet = book.active

sheet['A1'] = 1
sheet.cell(row=2, column=2).value = 2

book.save('write2cell.xlsx')