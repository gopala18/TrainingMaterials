'''
Created on 27-Nov-2017

@author: sayoojp
'''
s = 'Hello Python'
print str(s)
print str(2.0/11.0)

print repr(s)
print repr(2.0/11.0)


#Both str and repr are string representations



#__repr__ goal is to be unambiguous
#__str__ goal is to be readable

#str() is used for creating output for end user while repr() is mainly used for debugging and development. 


import datetime
today = datetime.datetime.now()
 
# Prints readable format for date-time object
print 'From str   '+str(today)
 
# prints the official format of date-time object
print 'From repr   '+repr(today)    