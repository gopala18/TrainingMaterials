class Person:
    def __init__(self, age, name):
        self.age = age
        self.name = name

   


    def __eq__(self, other):
        return  self.name == other.name and self.age==other.age
    
   # def __hash__(self):
    #    print'The hash of'+self.name+' is:'
     #   return hash((self.age, self.name))
    
person = Person(23, 'Adam')
person2=Person(23,'Sam')
person3=Person(23, 'Adam')
person4=person3
print(hash(person))
print(hash(person2))
print(hash(person3))

print(person.__eq__(person3))
if person==person3:
    print ("Both objects are equal")
else: 
    print("Both objects are not equal")