'''
Created on 06-Dec-2017

@author: sayoojp
'''
L = []
L.append(1)
if L == [1]:
    print 'Yay!'
print id(L)
B=L
c=[1]
print id(B)
print id(c)
# == checks content

if L is [1]:
    print 'Yay!'
# cheks whether they are same objects