'''
Created on 17-Jan-2017

@author: Sayooj
'''

import inheritance

empdao = inheritance.employeedaoimpl()
print empdao.insertemp("emp")
print empdao.getemployee("330")
