'''
Created on Dec 27, 2016

@author: sayoojp
'''
class MyError(Exception):       # should be inherited from Exception class
    def __init__(self, value):  #override the init method of exception class
        self.value = value
    def __str__(self):
        return repr(self.value) # converted to string and returned

try:
    raise MyError(2*2)
except MyError as e:
    print 'My exception occurred, value:', e