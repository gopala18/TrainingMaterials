'''
Created on 19-Jan-2017

@author: Sayooj
'''
from audioop import reverse
from operator import attrgetter

class product(object):
    """ Product class"""
    
    def __init__(self, productid, productname, unitprice, qty):
        self.productid=productid
        self.productname = productname
        self.unitprice = unitprice
        self.qty = qty;
        
    def __repr__(self):
        return self.productid+ ","+ self.productname+ "," + str(self.unitprice)+ "," + str(self.qty)    

    def __lt__(self, p1):
        return self.unitprice < p1.unitprice

    
products = []
products.append(product("p001","pen-1",50, 100))
products.append(product("p002","pencil",12, 110))
products.append(product("p003","eraser",6, 15))
products.append(product("p004","pen-2",57, 50))

def sort_by_unitprice_asc(product):
    return product.unitprice
def sort_by_qty_asc(product):
    return product.qty


so=sorted(products, key=sort_by_unitprice_asc, reverse=False)
#so = sorted(products)
print "Sorted by unitprice"+str(so)    

so = sorted(products, key=sort_by_qty_asc, reverse=True)
print so

so = sorted(products, key=attrgetter('productname'))
print so

so = sorted(products, key=lambda p :p.productid, reverse=True)
print so

so = sorted(products, key=lambda  p: (p.unitprice, p.qty))
print so

so = sorted(products, key=lambda  p: (p.unitprice, -p.qty))  # asc ->unitprice, asc -> qty      
print so 
