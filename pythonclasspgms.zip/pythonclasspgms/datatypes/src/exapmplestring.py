'''
Created on Dec 23, 2016

@author: sayoojp
'''
s='sayooj'
print(s[len(s)::-1])
raw_input()