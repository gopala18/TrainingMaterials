'''
Created on Dec 19, 2016

@author: sayoojp
'''
import math
import random
print 5//2
print 5//-2
print 5//-2.0
print 5/-2.0
print 5/-2
print math.pi, math.e
print eval('0100')
print eval('0x40')
print int('0x40', 16)
print "%o %x %x" % (64,64, 255)
print math.sin(30)
print random.random()
print random.randint(1,10)
print random.choice(['Life of Brain', 'Holy Grail', 'Meaning of Life' ])
x=set('abcde')
print x
y=set('bcd')
print y
print x-y
print x|y
print x&y
