'''
Created on Dec 23, 2016

@author: sayoojp
'''
li = []
print('enter a number')
for k in range(10):
    num = input()
    li.append(num)
print li   
for k in range(len(li)):
    print(li[k])
 
raw_input()