'''
Created on Dec 23, 2016

@author: sayoojp
'''
capitals ={'Italy': 'Rome', 'France': 'Paris', 'US' : 'Washington DC', 'UK':'London' }

for k  in capitals:
    print 'Country : ',k,' Capital :', capitals[k]
    print''
dict1 =  {}
dict1['one'] = 100
print dict1
dict1['two']= 200
dict1.update({'three': 300})
print dict1
#dict1={'two':200}
print dict1
raw_input()