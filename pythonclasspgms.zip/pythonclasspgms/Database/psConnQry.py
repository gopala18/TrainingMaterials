import psycopg2

try:
    conn = psycopg2.connect("dbname='postgres' user='openpg' host='localhost' password='openpgpwd'")
    print conn
     
except:
    print("Unable to connect to database")
      
try:
    cur = conn.cursor()
    cur.execute("""insert into persons values(25,'Sam','Chennai',80000)""")
    cur.execute("""select id,name,place,salary from persons""")
   
    rows = cur.fetchall()
    print("Retrieved data")
    for row in rows:
        print(row[0],"-",row[1],"-",row[2],"-",row[3])
except Exception as ex:
    print("i am not able to fetch the data",ex)
      
finally:
    conn.close()
      

      
