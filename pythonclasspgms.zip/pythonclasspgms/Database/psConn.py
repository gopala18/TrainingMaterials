import psycopg2

try:
    conn = psycopg2.connect("dbname='postgres' user='openpg' host='localhost' password='openpgpwd'")
    print(conn)
except:
    print("Unable to connect to database")
finally:
    conn.close()
          
      
