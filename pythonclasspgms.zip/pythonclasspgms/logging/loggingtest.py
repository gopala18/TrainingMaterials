'''
Created on 23-Jan-2017

@author: Sayooj
'''
import logging;
import logging.config

# using logging.conf file

logging.config.fileConfig("logging.conf")
logger = logging.getLogger(__name__)

logger.warning("This is a warning message")
