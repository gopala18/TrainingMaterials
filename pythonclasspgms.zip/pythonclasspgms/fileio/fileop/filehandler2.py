'''
Created on 18-Jan-2017

@author: sayooj
'''

try:
    pfile = open("product.txt", "w")
    pfile.write("PEN\n")
    pfile.write("PENCIL\n")
    pfile.write("ERASER\n")
except IOError as ex:
    print "Error-", ex
finally:
    pfile.close()
    print "File created"    
    
try:
    pfile = open("product.txt", "r")
    for line in pfile:
        print line
except IOError as ex:
    print ex
finally:
    pfile.close();
 
 # with clause
with open("product.txt", "r") as pfile:
    for line in pfile:
        print line
        