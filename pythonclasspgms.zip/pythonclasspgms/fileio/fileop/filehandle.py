'''
Created on 18-Jan-2017

@author: Sayooj
'''
import os

myfilew = open("python.txt", "w")
myfilew.write("This is a test myfile\n")
myfilew.write("This is to test myfile handling in python\n")
myfilew.write("This is a end line\n")
myfilew.close();
print "myfile created"

myfile = open("python.txt", "r")
lines = myfile.readlines()
for line in lines:
    print line
myfile.close()

print "----------------"


myfile = open("python.txt", "r")
print myfile.tell()
myfile.readline()
print myfile.tell();
myfile.close();

print "----------------"
myfile = open("python.txt", "r+")
print myfile.tell()
myfile.seek(21)
myfile.write("HTC")
print myfile.tell()
myfile.close();

print "myfilesize:" , os.path.getsize("python.txt")


