'''
Created on 28-Nov-2017

@author: sayoojp
'''
import prot
class tryprot:
    cup = prot.Cup()
    cup.color="RED"
    cup._content = "tea"  #Even though it is protected we are able to alter it
    print cup