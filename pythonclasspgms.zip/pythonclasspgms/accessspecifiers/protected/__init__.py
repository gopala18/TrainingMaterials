from prot import Cup
from checkprot import prot