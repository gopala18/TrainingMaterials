'''
Created on 28-Nov-2017

@author: sayoojp
'''
class Cup:
    def __init__(self):
        self.color = None
        self._content = None # protected variable accessible only within class and subclass
    def fill(self, beverage):
        self._content = beverage
    def empty(self):
        self._content = None
    def __repr__(self):
        return "color-{} content-{}".format(self.color,self._content)
