class Cup:
    def __init__(self):
        self.color = None
        self.content = None

    def fill(self, beverage):
        self.content = beverage

    def empty(self):
        self.content = None
    def __repr__(self):
        return "color-{} content-{}".format(self.color,self.content)

redCup = Cup()
redCup.color = "red"
redCup.content = "tea"
#redCup.empty()
redCup.fill("coffee")
print redCup