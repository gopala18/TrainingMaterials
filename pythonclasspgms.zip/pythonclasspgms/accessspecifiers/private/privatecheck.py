'''
Created on 28-Nov-2017

@author: sayoojp
'''
import privt
class testprivate:
    redCup = privt.Cup("red")
    #redCup.__content="tea"
    redCup._Cup__content = "tea"
    print redCup