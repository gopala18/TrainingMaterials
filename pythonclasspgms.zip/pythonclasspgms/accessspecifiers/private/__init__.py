from privt import Cup
from privatecheck import testprivate