'''
Created on 28-Nov-2017

@author: sayoojp
'''
class Cup:
    def __init__(self, color):
        self._color = color # protected variable
        self.__content = None # private variable
    def fill(self, beverage):
        self.__content = beverage
    def empty(self):
        self.__content = None
    def __repr__(self):
        return "color-{} content-{}".format(self._color,self.__content)
