'''
Created on 01-Dec-2017

@author: jamesashwin
'''

import bankfunc
import account

banknew = bankfunc.bankfunc("Axis Bank")

anacc =account.account("james",121,"asdf",4000.0)
banknew.create_account(anacc)

print(banknew.search_account(121))

while True:
    print("1. Create Account\n")
    print("2. Delete Account\n")
    print("3. Deposit\n")
    print("4. Withdraw\n")
    print("5. Transaction\n")
    print("6. Display")
    print("Enter your option\n")
    
    option = input()
    
    if option == 1:
        name = raw_input("Enter the name of the holder")
        account_num = input("Enter the account number for the account")
        branch = raw_input("Enter the branch of the account")
        balance = input("Enter the initial deposit")
        newacc =account.account(name, account_num, branch, balance)
        banknew.create_account(newacc)
        
    elif option == 2:
        del_acc = input("Enter the account number for deletion")
        del_status = banknew.delete_account(del_acc)
        if del_status == True:
            print("Account deleted")
        else:
            print("Account not found")
        
    elif option == 3:
        depacc = input("Enter the account number for deposition")
        depamt = input("Enter the deposit amount")
        dep_status = banknew.deposit_amount(depacc, depamt)
        if dep_status == True:
            print("Amount deposited")
        else:
            print("Amount not deposited")
            
    elif option == 4:
        withacc = input("Enter the account number for withdrawal")
        withamt = input("Enter the amount for withdrawal")
        with_status = banknew.withdraw_amount(withacc, withamt)
        if with_status == True:
            print("Withdrawal successful")
        else:
            print("Withdrawal not successful")
            
    elif option == 5:
        from_acc = input("Enter the account for withdrawal")
        to_acc = input("Enter the account for deposit")
        amt = input("Enter the amount for withdrawal")
        tran_stat = banknew.transaction(from_acc, to_acc, amt)
        print(tran_stat)
        
    elif option == 6:
        print(banknew.display_all())
        
    else:
        print("Enter a valid option")
    

