'''
Created on 01-Dec-2017

@author: jamesashwin
'''

class bankfunc(object):
    '''
    classdocs
    '''


    def __init__(self, bank_name=""):
        '''
        Constructor
        '''
        self._bank_name = bank_name
        self._account = []
        
    def create_account(self,newaccount):
        self._account.append(newaccount)
        
    def search_account(self, accno):
        emp = None
        for e in self._account:
            if e.getaccno()== accno:
                emp = e
                break
        return emp
        
    def delete_account(self, accno):
        removestatus = False
        for e in self._account:
            if e.search_account(accno) <> None:
                self._account.remove(accno)
                removestatus = True
        return removestatus
    
    def deposit_amount(self, accno, amount):
        depositstatus = False
        accountobject=self.search_account(accno)
        if accountobject <> None:
            newbalance = accountobject.getattr("balance") + amount
            accountobject.setattr("balance",newbalance)
            depositstatus = True
        return depositstatus
    
    def withdraw_amount(self, accno, amount):
        withdraw_status = False
        accountobject=self.search_account(accno)
        if  accountobject <> None:
            if accountobject.getattr("balance") > amount:
                newbalance =  accountobject.getattr("balance") - amount
                accountobject.setattr("balance",newbalance)
                withdraw_status = True
            else: 
                print("Insufficient funds")
        return withdraw_status
            
    
    def transaction(self, fromacc, toacc, amount):
        #for get in self._account:
         #   if get.search_account(fromacc) <> None:
          #      for sett in self._account:
           #         if sett.search_account(toacc) <> None:
        transactionstatus=True
        withdrawstatus=self.withdraw_amount(fromacc, amount)
        if(withdrawstatus==False):
            print"withdraw failed.Transaction failed"
            transactionstatus=False
            return transactionstatus
        print(withdrawstatus)
        depositstatus=self.deposit_amount(toacc, amount)
        if(depositstatus==False):
            print"deposit failed.Reverting the withdraw.Transaction failed"
            self.deposit_amount(fromacc, amount)
            transactionstatus=False
            return transactionstatus
        print(withdrawstatus)
        if (withdrawstatus==True and depositstatus==True):
            print("Transaction Succesful....")
            transactionstatus=True
        return transactionstatus
    
    
    def display_all(self):
        return self.__repr__()
    
    def __repr__(self):
        return self._account
            