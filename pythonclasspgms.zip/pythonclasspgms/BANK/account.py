'''
Created on 01-Dec-2017

@author: jamesashwin
'''

class account(object):
    '''
    classdocs
    '''


    def __init__(self, name="", acc_no=0, acc_branch="", balance=0.0):
        '''
        Constructor
        '''
        self._name = name
        self._accno = acc_no
        self._accbranch = acc_branch
        self._balance = balance
        
    def setaccno(self, acc_no):
        self._accno = acc_no
    
    def getaccno(self):
        return self._accno
    
    def getattr(self, attrname):
        if attrname == "name":
            return self._name
        elif attrname == "acc_no":
            return self._accno
        elif attrname == "acc_branch":
            return self._accbranch
        elif attrname == "balance":
            return self._balance
    
    def setattr(self, attrname,attrval):
        if attrname == "name":
            self._name = attrval
        elif attrname == "acc_no":
            self._accno = attrval
        elif attrname == "acc_branch":
            self._accbranch = attrval
        elif attrname == "balance":
            self._balance = attrval
            
    def __repr__(self):
        return "Name:{}  Account No:{}  Branch:{}  Balance:{}\n".format(self._name, self._accno, self._accbranch, self._balance)