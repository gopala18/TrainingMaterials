'''
Created on Dec 19, 2016

@author: sayoojp
'''
#from __future__ import division  
#to import true division
class Employee:
    def __init__(self,name,pay):
        self.name=name;
        self.pay=pay;
    def lastname(self):
        return self.name.split()[-1]
    def inreasepay(self,increment):
        self.pay *= (1.0 + increment)
John= Employee('John Hans',29000 );
John.inreasepay(.20)
print John.pay
print John.lastname()          
