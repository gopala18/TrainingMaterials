'''
Created on 12-Jan-2017
@author: Sayooj
'''
import empdep

emp = empdep.employee(1456, "Rahul", 5000.0)
#print emp.empno     

print emp
print emp.getattr("_empno")
print emp.getempno()


# Using department empdep
dept = empdep.department("Training")
dept.addemployee(empdep.employee(345,"charlie", 25000.0))
dept.addemployee(empdep.employee(346,"Harish", 35000.0))
dept.addemployee(empdep.employee(347,"vinod", 45000.0))
dept.addemployee(empdep.employee(348,"Manu Prasad", 65000.0))

print dept
print dept.removeemployee(347);
print dept


print dept.getemployee(345)

dept.incrementsalary(345, 20000.0)
print dept.getemployee(345)