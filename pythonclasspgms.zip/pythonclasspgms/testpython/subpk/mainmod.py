'''
Created on 04-Dec-2017

@author: sayoojp

'''
import testmod
obj=testmod.employee("vaibhav",15000)
print obj