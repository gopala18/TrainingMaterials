'''
Created on 04-Dec-2017

@author: sayoojp
'''
class employee:
    def __init__(self,name,salary):
        self.__empname=name
        self.__salary=salary
    def get_empname(self):
        return self.__empname


    def get_salary(self):
        return self.__salary


    def set_empname(self, value):
        self.__empname = value


    def set_salary(self, value):
        self.__salary = value


    def del_empname(self):
        del self.__empname


    def del_salary(self):
        del self.__salary

  
    empname = property(get_empname, set_empname, del_empname, "empname's docstring")
    salary = property(get_salary, set_salary, del_salary, "salary's docstring")
    def __str__(self):
        return "name={} salary={}".format(self.__empname,self.__salary)
    def __repr__(self):
        return "From repr name={} salary={}".format(self.__empname,self.__salary)
    
    
    