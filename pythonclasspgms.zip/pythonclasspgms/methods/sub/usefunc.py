'''
Created on 11-Jan-2017

@author: Sayooj
'''
import sub
print sub.addNumber(10, 20)
l=[100,300]
l1=['a','b']
sub.replaceListElement(l)
print l
l.append(l1)
print l
print sub.getTotalMarks(1,20,30)
print sub.getTotalMarks(1,20,30,40,50)
print sub.getTotalMarks(20,40,50,70,18,11)