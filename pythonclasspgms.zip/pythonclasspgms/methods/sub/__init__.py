from methods import addNumber
from methods import getTotalMarks
from methods import replaceListElement