'''
Created on 28-Nov-2017

@author: sayoojp
'''
class Human:
    def sayHello(self, **args):
       
        
        if args.get('name',None) is  None and args.get('age',None) is None:
            print ('Hello ' )
        elif args.get('age',None) is not None and args.get('name',None) is not None:
            print ('Hello ' + args['name']+' your are ' +args['age'] + ' years old !')
        elif args.get('name',None) is None and args.get('age',None) is not None:
            print ('Hello, your age is '+args['age'])
 
# Create instance
obj = Human()
# Call the method
obj.sayHello()
# Call the method with a parameter
obj.sayHello( name='Ad', age='23')
obj.sayHello(age='23')